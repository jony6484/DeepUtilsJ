

def inverse_dict(d: dict):
    return {v: k for k, v in d.items()}